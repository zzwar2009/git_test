'use strict';
import React from 'react';
import {
    View,
    Text,
    TextInput,
    TouchableHighlight,
    Modal
} from 'react-native';

import LinearGradient from 'react-native-linear-gradient';
import {FIELD_MAX_LENGTH} from '../constants/FieldMaxLengthTypes';
import styles from '../assets/styles/formModalStyle';
import {
    plIDval,
    mobileVeri,
    numTypeVeri,
    moneyTypeVeri,
    engTypeVeri,
    phoneVeri,
    postCodeVeri,
    emailVeri,
    engAndNumTypeVeri,
    SQLVeri,
    nameVeri,
    nameCHENVeri,
    addressVeri,
    phoneOrMobileVeri,
    interTypeVeri,
    socialCreditCodeVeri,
    equityRatioVeri,
} from '../utils/VerificatUtil';

class FormModalInput extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            changeText: null,
            verInfo: null,
            keyboardType: 'default',
            isPass: true
        };
        this.numberPad = [
            'CustIdNo', 'DECustMobile1', 'DECustMobile2', 'DECustMonthlySalaryIncome',
            'DELoanAmount', 'CustTel1', 'CustTel2', 'CustTel3', 'CustTel4', 'CustMobile1',
            'CustMobile2', 'CustResidencePostcode', 'CustRegisterPostcode', 'ContactPersonTel1',
            'ContactPersonTel2', 'ContactPersonTel3', 'ContactPersonTel4', 'ContactPersonMobile1',
            'ContactPersonMobile2', 'CustCompanyPostcode', 'CustCompanyTel1', 'CustCompanyTel2', 'LoanApplyDay',
            'CustCompanyTel3', 'CustCompanyTel4', 'CustWorkingYearsInCompay', 'CustWorkingMonthsInCompay',
            'CustTotalWorkingYears', 'CustTotalWorkingMonths', 'CustMonthlySalaryIncome', 'CustMonthlyRentIncome',
            'CustMonthlyBonusIncome', 'CustMonthlyOtherIncome', 'LoanAmount', 'LoanSelfPayment', 'LoanEntrustedPayment',
            'AreaOfDecoratedHouse', 'DecoratedFeeBuilding', 'DecoratedFeeAppliance', 'DecoratedFeeWork',
            'MarriageFreeWedding', 'MarriageFreeKing', 'FeeOfTravel', 'CarFee', 'PlanOfBrandORType', 'ProgramCost',
            'CustId', 'CustPostcode', 'CustAddrDuration', 'CustTelAreaCode', 'CustTelNo', 'CustMobile1',
            'CustMobile', 'ContactMobile1', 'ContactMobile', 'OtherContactMobile1', 'OtherContactMobile',
            'CustAnnualIncome', 'CustAnnualIncomeOthers', 'PWID', 'ComPostcode', 'ComTel1', 'ComTelAreaCode',
            'ComTel', 'ComTelExtension', 'SeniorityInCom', 'TotalSeniority', 'TotalMonth', 'ComRegCapital',
            'DDIRMBAccount', 'SecCustId', 'SecCustTelAreaCode', 'SecCustTelNo', 'SecCustMobile1', 'SecCustMobile',
            'PromoteId', 'EquityRatio', 'AnnualTurnover','EntrustedPayAmount1','EntrustedPayAmount2','EntrustedPayAmount3',
            'FinancialOfficerContact', 'FinancialOfficerAreaCode'
        ];
        this.emailPad = ['EmailAddr', 'CustEmail'];
    }

    componentWillMount() {
        let fieldName = this.props.modalCommon.fieldName;
        if (this.numberPad.indexOf(fieldName) > -1) {
            this.setState({
                keyboardType: 'numeric'
            });
        }

        if (this.emailPad.indexOf(fieldName) > -1) {
            this.setState({
                keyboardType: 'email-address'
            });
        }

        FIELD_MAX_LENGTH['CustResidenceOthers'] = this.props.modalCommon.itemValue['CustResidenceTerm'] === '003' ? 4
            : (this.props.modalCommon.itemValue['CustResidenceTerm'] === '005' ? 8
                : (this.props.modalCommon.itemValue['CustResidenceTerm'] === '006' ? 20 : null));

        FIELD_MAX_LENGTH['CustId'] = this.props.modalCommon.itemValue['CustIdType'] === '001' ? 18 : 19;
    }

    checkBirth(value, birthField) {
        let common = this.props.modalCommon,
            birth = common.itemValue[birthField],
            year = value.substr(6,4),
            month = value.substr(10,2),
            day = value.substr(12,2),
            birthDay = year + '-' + month + '-' + day;

        if(!birth){
            this.setState({
                verInfo: null,
                changeText: null
            });
            this.state.isPass = true;
        } else if (birth !== birthDay) {
            this.setState({
                verInfo: '身份证与生日不匹配'
            });
            this.state.isPass = false;
        } else {
            this.setState({
                verInfo: null,
                changeText: null
            });
            this.state.isPass = true;
        }
    }

    regexInputSQL(value) {
        this.setState({
            verInfo: SQLVeri(value)
        });
        return this.state.isPass = SQLVeri(value) === null ? true : false;
    }

    regexInputValue(value) {
        let common = this.props.modalCommon;
        const isIndividualOpLoan = this.props.modalCommon.itemValue['IndividualOpLoan'] === '001';

        switch (common.fieldName) {
        // 身份证验证
        case 'CustIdNo':
            if (plIDval(value) !== true) {
                this.setState({
                    verInfo: plIDval(value)
                });
                this.state.isPass = false;
            } else if (value) {
                this.checkBirth(value, 'CustDOB');
            }
            return this.state.isPass;
        case 'CustId':
            if (common.itemValue['CustIdType'] === '001') {
                if (plIDval(value) !== true) {
                    this.setState({
                        verInfo: plIDval(value)
                    });
                    this.state.isPass = false;
                } else {
                    this.checkBirth(value, 'CustDateOfBirth');
                }
                return this.state.isPass;
            } else {
                this.setState({
                    verInfo: engAndNumTypeVeri(value)
                });
                return this.state.isPass = (numTypeVeri(value) === null || engAndNumTypeVeri(value) === null) ? true : false;
            }
        case 'SecCustId':
            if (common.itemValue['SecCustIdType'] === '001') {
                if (plIDval(value) !== true) {
                    this.setState({
                        verInfo: plIDval(value)
                    });
                    this.state.isPass = false;
                } else {
                    this.checkBirth(value, 'SecCustDateOfBirth');
                }
                return this.state.isPass;
            } else {
                this.setState({
                    verInfo: engAndNumTypeVeri(value)
                });
                return this.state.isPass = (numTypeVeri(value) === null || engAndNumTypeVeri(value) === null) ? true : false;
            }
        // 国家号码
        case 'DECustMobile1':
            this.setState({
                verInfo: numTypeVeri(value)
            });
            return this.state.isPass = numTypeVeri(value) === null ? true : false;
        case 'CustMobile1':
            this.setState({
                verInfo: numTypeVeri(value)
            });
            return this.state.isPass = numTypeVeri(value) === null ? true : false;
        case 'ContactMobile1':
            this.setState({
                verInfo: numTypeVeri(value)
            });
            return this.state.isPass = numTypeVeri(value) === null ? true : false;
        case 'OtherContactMobile1':
            this.setState({
                verInfo: numTypeVeri(value)
            });
            return this.state.isPass = numTypeVeri(value) === null ? true : false;
        case 'SecCustMobile1':
            this.setState({
                verInfo: numTypeVeri(value)
            });
            return this.state.isPass = numTypeVeri(value) === null ? true : false;
        case 'ComTel1':
            this.setState({
                verInfo: numTypeVeri(value)
            });
            return this.state.isPass = numTypeVeri(value) === null ? true : false;
        case 'CustCompanyTel1':
            this.setState({
                verInfo: numTypeVeri(value)
            });
            return this.state.isPass = numTypeVeri(value) === null ? true : false;
        case 'CustTel1':
            this.setState({
                verInfo: numTypeVeri(value)
            });
            return this.state.isPass = numTypeVeri(value) === null ? true : false;
        case 'ContactPersonTel1':
            this.setState({
                verInfo: numTypeVeri(value)
            });
            return this.state.isPass = numTypeVeri(value) === null ? true : false;
        case 'ContactPersonMobile1':
            this.setState({
                verInfo: numTypeVeri(value)
            });
            return this.state.isPass = numTypeVeri(value) === null ? true : false;
        // 手机号验证
        case 'DECustMobile2':
            this.setState({
                verInfo: mobileVeri(value)
            });
            return this.state.isPass = mobileVeri(value) === null ? true : false;
        case 'CustMobile2':
            this.setState({
                verInfo: mobileVeri(value)
            });
            return this.state.isPass = mobileVeri(value) === null ? true : false;
        case 'ContactPersonMobile2':
            this.setState({
                verInfo: mobileVeri(value)
            });
            return this.state.isPass = mobileVeri(value) === null ? true : false;
        case 'CustMobile':
            this.setState({
                verInfo: mobileVeri(value)
            });
            return this.state.isPass = mobileVeri(value) === null ? true : false;
        case 'ContactMobile':
            this.setState({
                verInfo: mobileVeri(value)
            });
            return this.state.isPass = mobileVeri(value) === null ? true : false;
        case 'OtherContactMobile':
            this.setState({
                verInfo: mobileVeri(value)
            });
            return this.state.isPass = mobileVeri(value) === null ? true : false;
        case 'SecCustMobile':
            this.setState({
                verInfo: mobileVeri(value)
            });
            return this.state.isPass = mobileVeri(value) === null ? true : false;
        // 收入验证
        case 'DECustMonthlySalaryIncome':
            this.setState({
                verInfo: moneyTypeVeri(value)
            });
            return this.state.isPass = moneyTypeVeri(value) === null ? true : false;
        case 'CustMonthlySalaryIncome':
            this.setState({
                verInfo: moneyTypeVeri(value)
            });

            if (moneyTypeVeri(value) === null) {
                if (parseInt(value) >= 3000) {
                    this.state.isPass = true;
                } else {
                    this.setState({verInfo: '输入金额需大于等于3000元'});
                    this.state.isPass = false;
                }
            } else {
                this.state.isPass = false;
            }
            return this.state.isPass;
        case 'CustMonthlyRentIncome':
            this.setState({
                verInfo: moneyTypeVeri(value)
            });
            return this.state.isPass = moneyTypeVeri(value) === null ? true : false;
        case 'CustMonthlyBonusIncome':
            this.setState({
                verInfo: moneyTypeVeri(value)
            });
            return this.state.isPass = moneyTypeVeri(value) === null ? true : false;
        case 'CustMonthlyOtherIncome':
            this.setState({
                verInfo: moneyTypeVeri(value)
            });
            return this.state.isPass = moneyTypeVeri(value) === null ? true : false;
        case 'CustAnnualIncome':
            this.setState({
                verInfo: moneyTypeVeri(value)
            });
            return this.state.isPass = moneyTypeVeri(value) === null ? true : false;
        case 'CustAnnualIncomeOthers':
            this.setState({
                verInfo: moneyTypeVeri(value)
            });
            return this.state.isPass = moneyTypeVeri(value) === null ? true : false;
        // 总金额验证
        case 'DELoanAmount':
            this.setState({
                verInfo: moneyTypeVeri(value)
            });

            let minAmount = isIndividualOpLoan ? 30000 : 8000;
            let maxAmount = isIndividualOpLoan ? 300000 : 500000;

            if (moneyTypeVeri(value) === null) {
                if (parseInt(value) >= minAmount && parseInt(value) <= maxAmount) {
                    this.state.isPass = true;
                } else {
                    this.setState({verInfo: '输入金额需在' + minAmount + '-'+maxAmount+'之间'});
                    this.state.isPass = false;
                }
            } else {
                this.state.isPass = false;
            }
            return this.state.isPass;
        case 'LoanAmount':
            this.setState({
                verInfo: moneyTypeVeri(value)
            });

            minAmount = isIndividualOpLoan ? 30000 : 8000;
            maxAmount = isIndividualOpLoan ? 300000 : 500000;

            if (moneyTypeVeri(value) === null) {
                if (parseInt(value) >= minAmount && parseInt(value) <= maxAmount) {
                    this.state.isPass = true;
                } else {
                    this.setState({verInfo: '输入金额需在' + minAmount + '-'+maxAmount+'之间'});
                    this.state.isPass = false;
                }
            } else {
                this.state.isPass = false;
            }
            return this.state.isPass;
        case 'LoanSelfPayment':
            this.setState({
                verInfo: moneyTypeVeri(value)
            });
            return this.state.isPass = moneyTypeVeri(value) === null ? true : false;
        case 'EntrustedPayAmount1':
            this.setState({
                verInfo: moneyTypeVeri(value)
            });
            return this.state.isPass = moneyTypeVeri(value) === null ? true : false;
        case 'EntrustedPayAmount2':
            this.setState({
                verInfo: moneyTypeVeri(value)
            });
            return this.state.isPass = moneyTypeVeri(value) === null ? true : false;
        case 'EntrustedPayAmount3':
            this.setState({
                verInfo: moneyTypeVeri(value)
            });
            return this.state.isPass = moneyTypeVeri(value) === null ? true : false;
        case 'LoanEntrustedPayment':
            this.setState({
                verInfo: moneyTypeVeri(value)
            });
            return this.state.isPass = moneyTypeVeri(value) === null ? true : false;
        case 'ComRegCapital':
            this.setState({
                verInfo: moneyTypeVeri(value)
            });
            return this.state.isPass = moneyTypeVeri(value) === null ? true : false;
        case 'CustResidenceOthers':
            if (common.itemValue['CustResidenceTerm'] !== '006') {
                this.setState({
                    verInfo: moneyTypeVeri(value)
                });
                return this.state.isPass = moneyTypeVeri(value) === null ? true : false;
            } else {
                this.setState({
                    verInfo: addressVeri(value, FIELD_MAX_LENGTH['CustResidenceOthers'])
                });
                return this.state.isPass = addressVeri(value, FIELD_MAX_LENGTH['CustResidenceOthers']) === null ? true : false;
            }
        // 拼音验证
        case 'CustNamePY':
            this.setState({
                verInfo: engTypeVeri(value)
            });
            return this.state.isPass = engTypeVeri(value) === null ? true : false;
        // 区号验证
        case 'CustTel2':
            this.setState({
                verInfo: numTypeVeri(value)
            });
            return this.state.isPass = numTypeVeri(value) === null ? true : false;
        case 'ContactPersonTel2':
            this.setState({
                verInfo: numTypeVeri(value)
            });
            return this.state.isPass = numTypeVeri(value) === null ? true : false;
        case 'CustCompanyTel2':
            this.setState({
                verInfo: numTypeVeri(value)
            });
            return this.state.isPass = numTypeVeri(value) === null ? true : false;
        case 'CustTelAreaCode':
            this.setState({
                verInfo: numTypeVeri(value)
            });
            return this.state.isPass = numTypeVeri(value) === null ? true : false;
        case 'ComTelAreaCode':
            this.setState({
                verInfo: numTypeVeri(value)
            });
            return this.state.isPass = numTypeVeri(value) === null ? true : false;
        case 'SecCustTelAreaCode':
            this.setState({
                verInfo: numTypeVeri(value)
            });
            return this.state.isPass = numTypeVeri(value) === null ? true : false;
        // 固定电话验证
        case 'CustTel3':
            this.setState({
                verInfo: phoneOrMobileVeri(value)
            });
            return this.state.isPass = phoneOrMobileVeri(value) === null ? true : false;
        case 'ContactPersonTel3':
            this.setState({
                verInfo: phoneVeri(value)
            });
            return this.state.isPass = phoneVeri(value) === null ? true : false;
        case 'CustCompanyTel3':
            this.setState({
                verInfo: phoneVeri(value)
            });
            return this.state.isPass = phoneVeri(value) === null ? true : false;
        case 'CustTelNo':
            this.setState({
                verInfo: phoneVeri(value)
            });
            return this.state.isPass = phoneVeri(value) === null ? true : false;
        case 'ComTel':
            this.setState({
                verInfo: phoneVeri(value)
            });
            return this.state.isPass = phoneVeri(value) === null ? true : false;
        case 'ComTelExtension':
            this.setState({
                verInfo: numTypeVeri(value)
            });
            return this.state.isPass = numTypeVeri(value) === null ? true : false;
        case 'SecCustTelNo':
            this.setState({
                verInfo: phoneVeri(value)
            });
            return this.state.isPass = phoneVeri(value) === null ? true : false;
        // 邮编验证
        case 'CustResidencePostcode':
            this.setState({
                verInfo: postCodeVeri(value)
            });
            return this.state.isPass = postCodeVeri(value) === null ? true : false;
        case 'CustRegisterPostcode':
            this.setState({
                verInfo: postCodeVeri(value)
            });
            return this.state.isPass = postCodeVeri(value) === null ? true : false;
        case 'CustCompanyPostcode':
            this.setState({
                verInfo: postCodeVeri(value)
            });
            return this.state.isPass = postCodeVeri(value) === null ? true : false;
        case 'CustPostcode':
            this.setState({
                verInfo: postCodeVeri(value)
            });
            return this.state.isPass = postCodeVeri(value) === null ? true : false;
        case 'ComPostcode':
            this.setState({
                verInfo: postCodeVeri(value)
            });
            return this.state.isPass = postCodeVeri(value) === null ? true : false;
        // 工作年限验证
        case 'CustWorkingYearsInCompay':
            this.setState({
                verInfo: numTypeVeri(value)
            });
            return this.state.isPass = numTypeVeri(value) === null ? true : false;
        case 'CustWorkingMonthsInCompay':
            this.setState({
                verInfo: numTypeVeri(value)
            });

            if (numTypeVeri(value) === null) {
                if (!parseInt(value) || (parseInt(value) >= 0 && parseInt(value) <= 11)) {
                    this.state.isPass = true;
                } else {
                    this.setState({verInfo: '请输入正确月份'});
                    this.state.isPass = false;
                }
            } else {
                this.state.isPass = false;
            }
            return this.state.isPass;
        case 'CustTotalWorkingYears':
            this.setState({
                verInfo: numTypeVeri(value)
            });
            return this.state.isPass = numTypeVeri(value) === null ? true : false;
        case 'CustTotalWorkingMonths':
            this.setState({
                verInfo: numTypeVeri(value)
            });

            if (numTypeVeri(value) === null) {
                if (!parseInt(value) || (parseInt(value) >= 0 && parseInt(value) <= 11)) {
                    this.state.isPass = true;
                } else {
                    this.setState({verInfo: '请输入正确月份'});
                    this.state.isPass = false;
                }
            } else {
                this.state.isPass = false;
            }
            return this.state.isPass;
        case 'SeniorityInCom':
            this.setState({
                verInfo: numTypeVeri(value)
            });
            return this.state.isPass = numTypeVeri(value) === null ? true : false;
        case 'TotalSeniority':
            this.setState({
                verInfo: numTypeVeri(value)
            });
            return this.state.isPass = numTypeVeri(value) === null ? true : false;
        case 'TotalMonth':
            this.setState({
                verInfo: numTypeVeri(value)
            });

            if (numTypeVeri(value) === null) {
                if (!parseInt(value) || (parseInt(value) >= 0 && parseInt(value) <= 11)) {
                    this.state.isPass = true;
                } else {
                    this.setState({verInfo: '请输入正确月份'});
                    this.state.isPass = false;
                }
            } else {
                this.state.isPass = false;
            }
            return this.state.isPass;
        // 房产详情面积和费用验证
        case 'AreaOfDecoratedHouse':
            this.setState({
                verInfo: numTypeVeri(value)
            });
            return this.state.isPass = numTypeVeri(value) === null ? true : false;
        case 'DecoratedFeeBuilding':
            this.setState({
                verInfo: numTypeVeri(value)
            });
            return this.state.isPass = numTypeVeri(value) === null ? true : false;
        case 'DecoratedFeeAppliance':
            this.setState({
                verInfo: numTypeVeri(value)
            });
            return this.state.isPass = numTypeVeri(value) === null ? true : false;
        case 'DecoratedFeeWork':
            this.setState({
                verInfo: numTypeVeri(value)
            });
            return this.state.isPass = numTypeVeri(value) === null ? true : false;
        case 'MarriageFreeWedding':
            this.setState({
                verInfo: numTypeVeri(value)
            });
            return this.state.isPass = numTypeVeri(value) === null ? true : false;
        case 'MarriageFreeKing':
            this.setState({
                verInfo: numTypeVeri(value)
            });
            return this.state.isPass = numTypeVeri(value) === null ? true : false;
        // 旅游费用验证
        case 'FeeOfTravel':
            this.setState({
                verInfo: numTypeVeri(value)
            });
            return this.state.isPass = numTypeVeri(value) === null ? true : false;
        // 耐用消费品费家具用验证
        case 'CarFee':
            this.setState({
                verInfo: numTypeVeri(value)
            });
            return this.state.isPass = numTypeVeri(value) === null ? true : false;
            // 耐用消费品家电费用验证
        case 'PlanOfBrandORType':
            this.setState({
                verInfo: numTypeVeri(value)
            });
            return this.state.isPass = numTypeVeri(value) === null ? true : false;
        // 进修或学习的项目预计所需费用验证
        case 'ProgramCost':
            this.setState({
                verInfo: numTypeVeri(value)
            });
            return this.state.isPass = numTypeVeri(value) === null ? true : false;
        // AIP姓名验证
        case 'CustName':
            this.setState({
                verInfo: nameVeri(value, FIELD_MAX_LENGTH['CustName'])
            });
            return this.state.isPass = nameVeri(value, FIELD_MAX_LENGTH['CustName']) === null ? true : false;
        case 'ContactPersonName':
            this.setState({
                verInfo: nameVeri(value, FIELD_MAX_LENGTH['ContactPersonName'])
            });
            return this.state.isPass = nameVeri(value, FIELD_MAX_LENGTH['ContactPersonName']) === null ? true : false;
        // 中文姓名验证
        case 'CustNameCN':
            this.setState({
                verInfo: nameCHENVeri(value, FIELD_MAX_LENGTH['CustNameCN'])
            });
            return this.state.isPass = nameCHENVeri(value, FIELD_MAX_LENGTH['CustNameCN']) === null ? true : false;
        case 'SecCustNameCN':
            this.setState({
                verInfo: nameCHENVeri(value, FIELD_MAX_LENGTH['SecCustNameCN'])
            });
            return this.state.isPass = nameCHENVeri(value, FIELD_MAX_LENGTH['SecCustNameCN']) === null ? true : false;
        // 名称地址长度验证
        // case 'CustIdPlaceOfIssue':
        //     this.setState({
        //         verInfo: addressVeri(value, FIELD_MAX_LENGTH['CustIdPlaceOfIssue'])
        //     });
        //     return this.state.isPass = addressVeri(value, FIELD_MAX_LENGTH['CustIdPlaceOfIssue']) === null ? true : false;
        case 'ContactPerson':
            this.setState({
                verInfo: addressVeri(value, FIELD_MAX_LENGTH['ContactPerson'])
            });
            return this.state.isPass = addressVeri(value, FIELD_MAX_LENGTH['ContactPerson']) === null ? true : false;
        case 'OtherContactPerson':
            this.setState({
                verInfo: addressVeri(value, FIELD_MAX_LENGTH['OtherContactPerson'])
            });
            return this.state.isPass = addressVeri(value, FIELD_MAX_LENGTH['OtherContactPerson']) === null ? true : false;
        case 'Job':
            this.setState({
                verInfo: addressVeri(value, FIELD_MAX_LENGTH['Job'])
            });
            return this.state.isPass = addressVeri(value, FIELD_MAX_LENGTH['Job']) === null ? true : false;
        // case 'SecCustIdPlaceOfIssue':
        //     this.setState({
        //         verInfo: addressVeri(value, FIELD_MAX_LENGTH['SecCustIdPlaceOfIssue'])
        //     });
        //     return this.state.isPass = addressVeri(value, FIELD_MAX_LENGTH['SecCustIdPlaceOfIssue']) === null ? true : false;
        // case 'CustAddrFour':
        //     this.setState({
        //         verInfo: addressVeri(value, FIELD_MAX_LENGTH['CustAddrFour'])
        //     });
        //     return this.state.isPass = addressVeri(value, FIELD_MAX_LENGTH['CustAddrFour']) === null ? true : false;
        // case 'ContactAddrFour':
        //     this.setState({
        //         verInfo: addressVeri(value, FIELD_MAX_LENGTH['ContactAddrFour'])
        //     });
        //     return this.state.isPass = addressVeri(value, FIELD_MAX_LENGTH['ContactAddrFour']) === null ? true : false;
        case 'EmployerName':
            this.setState({
                verInfo: addressVeri(value, FIELD_MAX_LENGTH['EmployerName'])
            });
            return this.state.isPass = addressVeri(value, FIELD_MAX_LENGTH['EmployerName']) === null ? true : false;
        case 'Department':
            this.setState({
                verInfo: addressVeri(value, FIELD_MAX_LENGTH['Department'])
            });
            return this.state.isPass = addressVeri(value, FIELD_MAX_LENGTH['Department']) === null ? true : false;
        case 'CustRelationshipWithHouseOwner':
            this.setState({
                verInfo: addressVeri(value, FIELD_MAX_LENGTH['CustRelationshipWithHouseOwner'])
            });
            return this.state.isPass = addressVeri(value, FIELD_MAX_LENGTH['CustRelationshipWithHouseOwner']) === null ? true : false;
        // case 'ComAddrFour':
        //     this.setState({
        //         verInfo: addressVeri(value, FIELD_MAX_LENGTH['ComAddrFour'])
        //     });
        //     return this.state.isPass = addressVeri(value, FIELD_MAX_LENGTH['ComAddrFour']) === null ? true : false;
        case 'ComIndustryOther':
            this.setState({
                verInfo: addressVeri(value, FIELD_MAX_LENGTH['ComIndustryOther'])
            });
            return this.state.isPass = addressVeri(value, FIELD_MAX_LENGTH['ComIndustryOther']) === null ? true : false;
        case 'ComNatureOther':
            this.setState({
                verInfo: addressVeri(value, FIELD_MAX_LENGTH['ComNatureOther'])
            });
            return this.state.isPass = addressVeri(value, FIELD_MAX_LENGTH['ComNatureOther']) === null ? true : false;
        case 'NameOfComInSCB':
            this.setState({
                verInfo: addressVeri(value, FIELD_MAX_LENGTH['NameOfComInSCB'])
            });
            return this.state.isPass = addressVeri(value, FIELD_MAX_LENGTH['NameOfComInSCB']) === null ? true : false;
        // case 'SecResidenceAddrFour':
        //     this.setState({
        //         verInfo: addressVeri(value, FIELD_MAX_LENGTH['SecResidenceAddrFour'])
        //     });
        //     return this.state.isPass = addressVeri(value, FIELD_MAX_LENGTH['SecResidenceAddrFour']) === null ? true : false;
        case 'DECustCompany':
            this.setState({
                verInfo: addressVeri(value, FIELD_MAX_LENGTH['DECustCompany'])
            });
            return this.state.isPass = addressVeri(value, FIELD_MAX_LENGTH['DECustCompany']) === null ? true : false;
        case 'CustPositionOthers':
            this.setState({
                verInfo: addressVeri(value, FIELD_MAX_LENGTH['CustPositionOthers'])
            });
            return this.state.isPass = addressVeri(value, FIELD_MAX_LENGTH['CustPositionOthers']) === null ? true : false;
        case 'CustBornCountry':
            this.setState({
                verInfo: addressVeri(value, FIELD_MAX_LENGTH['CustBornCountry'])
            });
            return this.state.isPass = addressVeri(value, FIELD_MAX_LENGTH['CustBornCountry']) === null ? true : false;
        case 'CustResidenceCountry':
            this.setState({
                verInfo: addressVeri(value, FIELD_MAX_LENGTH['CustResidenceCountry'])
            });
            return this.state.isPass = addressVeri(value, FIELD_MAX_LENGTH['CustResidenceCountry']) === null ? true : false;
        case 'CustResidenceAddr3':
            this.setState({
                verInfo: addressVeri(value, FIELD_MAX_LENGTH['CustResidenceAddr3'])
            });
            return this.state.isPass = addressVeri(value, FIELD_MAX_LENGTH['CustResidenceAddr3']) === null ? true : false;
        case 'CustResidenceAddr4':
            this.setState({
                verInfo: addressVeri(value, FIELD_MAX_LENGTH['CustResidenceAddr4'])
            });
            return this.state.isPass = addressVeri(value, FIELD_MAX_LENGTH['CustResidenceAddr4']) === null ? true : false;
        case 'CustRegisterAddr3':
            this.setState({
                verInfo: addressVeri(value, FIELD_MAX_LENGTH['CustRegisterAddr3'])
            });
            return this.state.isPass = addressVeri(value, FIELD_MAX_LENGTH['CustRegisterAddr3']) === null ? true : false;
        case 'CustRegisterAddr4':
            this.setState({
                verInfo: addressVeri(value, FIELD_MAX_LENGTH['CustRegisterAddr4'])
            });
            return this.state.isPass = addressVeri(value, FIELD_MAX_LENGTH['CustRegisterAddr4']) === null ? true : false;
        case 'CustRelationshipWithBankOthers':
            this.setState({
                verInfo: addressVeri(value, FIELD_MAX_LENGTH['CustRelationshipWithBankOthers'])
            });
            return this.state.isPass = addressVeri(value, FIELD_MAX_LENGTH['CustRelationshipWithBankOthers']) === null ? true : false;
        case 'ContactPersonAddr':
            this.setState({
                verInfo: addressVeri(value, FIELD_MAX_LENGTH['ContactPersonAddr'])
            });
            return this.state.isPass = addressVeri(value, FIELD_MAX_LENGTH['ContactPersonAddr']) === null ? true : false;
        case 'CustDepartment':
            this.setState({
                verInfo: addressVeri(value, FIELD_MAX_LENGTH['CustDepartment'])
            });
            return this.state.isPass = addressVeri(value, FIELD_MAX_LENGTH['CustDepartment']) === null ? true : false;
        case 'CustCompanyAddr3':
            this.setState({
                verInfo: addressVeri(value, FIELD_MAX_LENGTH['CustCompanyAddr3'])
            });
            return this.state.isPass = addressVeri(value, FIELD_MAX_LENGTH['CustCompanyAddr3']) === null ? true : false;
        case 'CustCompanyAddr4':
            this.setState({
                verInfo: addressVeri(value, FIELD_MAX_LENGTH['CustCompanyAddr4'])
            });
            return this.state.isPass = addressVeri(value, FIELD_MAX_LENGTH['CustCompanyAddr4']) === null ? true : false;
        case 'CustIndustryNatureOthers':
            this.setState({
                verInfo: addressVeri(value, FIELD_MAX_LENGTH['CustIndustryNatureOthers'])
            });
            return this.state.isPass = addressVeri(value, FIELD_MAX_LENGTH['CustIndustryNatureOthers']) === null ? true : false;
        case 'CustCompanyNatureOthers':
            this.setState({
                verInfo: addressVeri(value, FIELD_MAX_LENGTH['CustCompanyNatureOthers'])
            });
            return this.state.isPass = addressVeri(value, FIELD_MAX_LENGTH['CustCompanyNatureOthers']) === null ? true : false;
        case 'CustJobTitle':
            this.setState({
                verInfo: addressVeri(value, FIELD_MAX_LENGTH['CustJobTitle'])
            });
            return this.state.isPass = addressVeri(value, FIELD_MAX_LENGTH['CustJobTitle']) === null ? true : false;
        case 'CustIncomeSourceOthers':
            this.setState({
                verInfo: addressVeri(value, FIELD_MAX_LENGTH['CustIncomeSourceOthers'])
            });
            return this.state.isPass = addressVeri(value, FIELD_MAX_LENGTH['CustIncomeSourceOthers']) === null ? true : false;
        case 'EstimateDateOfMarriage':
            this.setState({
                verInfo: addressVeri(value, FIELD_MAX_LENGTH['EstimateDateOfMarriage'])
            });
            return this.state.isPass = addressVeri(value, FIELD_MAX_LENGTH['EstimateDateOfMarriage']) === null ? true : false;
        case 'MarriageFreeOthers':
            this.setState({
                verInfo: addressVeri(value, FIELD_MAX_LENGTH['MarriageFreeOthers'])
            });
            return this.state.isPass = addressVeri(value, FIELD_MAX_LENGTH['MarriageFreeOthers']) === null ? true : false;
        case 'CityOfDecoratedHouse':
            this.setState({
                verInfo: addressVeri(value, FIELD_MAX_LENGTH['CityOfDecoratedHouse'])
            });
            return this.state.isPass = addressVeri(value, FIELD_MAX_LENGTH['CityOfDecoratedHouse']) === null ? true : false;
        case 'DecoratedFeeOthers':
            this.setState({
                verInfo: addressVeri(value, FIELD_MAX_LENGTH['DecoratedFeeOthers'])
            });
            return this.state.isPass = addressVeri(value, FIELD_MAX_LENGTH['DecoratedFeeOthers']) === null ? true : false;
        case 'DateOfTravel':
            this.setState({
                verInfo: addressVeri(value, FIELD_MAX_LENGTH['DateOfTravel'])
            });
            return this.state.isPass = addressVeri(value, FIELD_MAX_LENGTH['DateOfTravel']) === null ? true : false;
        case 'DestinationOfTravel':
            this.setState({
                verInfo: addressVeri(value, FIELD_MAX_LENGTH['DestinationOfTravel'])
            });
            return this.state.isPass = addressVeri(value, FIELD_MAX_LENGTH['DestinationOfTravel']) === null ? true : false;
        case 'ProgramDuration':
            this.setState({
                verInfo: addressVeri(value, FIELD_MAX_LENGTH['ProgramDuration'])
            });
            return this.state.isPass = addressVeri(value, FIELD_MAX_LENGTH['ProgramDuration']) === null ? true : false;
        case 'LoanPurposeOthers':
            this.setState({
                verInfo: addressVeri(value, FIELD_MAX_LENGTH['LoanPurposeOthers'])
            });
            return this.state.isPass = addressVeri(value, FIELD_MAX_LENGTH['LoanPurposeOthers']) === null ? true : false;
        case 'SalesMark':
            this.setState({
                verInfo: addressVeri(value, FIELD_MAX_LENGTH['SalesMark'])
            });
            return this.state.isPass = addressVeri(value, FIELD_MAX_LENGTH['SalesMark']) === null ? true : false;
        // 英文姓名验证
        case 'CustNameEN':
            this.setState({
                verInfo: engTypeVeri(value)
            });
            return this.state.isPass = engTypeVeri(value) === null ? true : false;
        case 'SecCustNameEN':
            this.setState({
                verInfo: engTypeVeri(value)
            });
            return this.state.isPass = engTypeVeri(value) === null ? true : false;
        case 'Surname':
            this.setState({
                verInfo: engTypeVeri(value)
            });
            return this.state.isPass = engTypeVeri(value) === null ? true : false;
        case 'Firstname':
            this.setState({
                verInfo: engTypeVeri(value)
            });
            return this.state.isPass = engTypeVeri(value) === null ? true : false;
        case 'SecSurname':
            this.setState({
                verInfo: engTypeVeri(value)
            });
            return this.state.isPass = engTypeVeri(value) === null ? true : false;
        case 'SecFirstname':
            this.setState({
                verInfo: engTypeVeri(value)
            });
            return this.state.isPass = engTypeVeri(value) === null ? true : false;
        // 居住时间验证
        case 'CustAddrDuration':
            this.setState({
                verInfo: numTypeVeri(value)
            });
            return this.state.isPass = numTypeVeri(value) === null ? true : false;
        // 电子邮箱验证
        case 'CustEmail':
            this.setState({
                verInfo: emailVeri(value)
            });
            return this.state.isPass = emailVeri(value) === null ? true : false;
        // 还款账号验证
        case 'DDIRMBAccount':
            this.setState({
                verInfo: numTypeVeri(value)
            });
            return this.state.isPass = numTypeVeri(value) === null ? true : false;
        // 工资发放日验证
        case 'LoanApplyDay':
            this.setState({
                verInfo: numTypeVeri(value)
            });

            if (numTypeVeri(value) === null) {
                if (!parseInt(value) || (parseInt(value) >= 1 && parseInt(value) <= 31)) {
                    this.state.isPass = true;
                } else {
                    this.setState({verInfo: '工资发放日应在1-31之间'});
                    this.state.isPass = false;
                }
            } else {
                this.state.isPass = false;
            }
            return this.state.isPass;
        // 数字验证
        case 'PromoteId':
            this.setState({
                verInfo: numTypeVeri(value)
            });
            return this.state.isPass = numTypeVeri(value) === null ? true : false;
        case 'PWID':
            this.setState({
                verInfo: numTypeVeri(value)
            });

            if (numTypeVeri(value) === null) {
                if (value.length === 7 || value.length === 0) {
                    this.state.isPass = true;
                } else {
                    this.setState({verInfo: '请填写7位数字员工号'});
                    this.state.isPass = false;
                }
            } else {
                this.state.isPass = false;
            }
            return this.state.isPass;
        // MerChant ID验证
        case 'MerchantId':
            this.setState({
                verInfo: engAndNumTypeVeri(value)
            });
            return this.state.isPass = engAndNumTypeVeri(value) === null ? true : false;
        case 'calculaterMoney':
            this.setState({
                verInfo: moneyTypeVeri(value)
            });

            if (moneyTypeVeri(value) === null) {
                if (parseInt(value) >= 8000 && parseInt(value) <= 500000) {
                    this.state.isPass = true;
                } else {
                    this.setState({verInfo: '输入金额需在8000-500000之间'});
                    this.state.isPass = false;
                }
            } else {
                this.state.isPass = false;
            }
            return this.state.isPass;
        case 'calculaterInter':
            const veriResult = interTypeVeri(value);
            if (veriResult === null) {
                this.state.isPass = true;
            } else {
                this.setState({verInfo: veriResult});
                this.state.isPass = false;
            }
            return this.state.isPass;
        case 'SocialCreditCode':
            if (socialCreditCodeVeri(value) === null) {
                this.state.isPass = true;
            } else {
                this.setState({verInfo: socialCreditCodeVeri(value)});
                this.state.isPass = false;
            }
            return this.state.isPass;
        case 'AnnualTurnover':
            if (numTypeVeri(value) === null) {
                this.state.isPass = true;
            } else {
                this.setState({verInfo: '注册资本请精确到万元'});
                this.state.isPass = false;
            }
            return this.state.isPass;
        case 'EquityRatio':
            this.setState({
                verInfo: equityRatioVeri(value)
            });
            return this.state.isPass = equityRatioVeri(value) === null ? true : false;
        case 'FinancialOfficerAreaCode':
            this.setState({
                verInfo: numTypeVeri(value)
            });
            return this.state.isPass = numTypeVeri(value) === null ? true : false;
        case 'FinancialOfficerContact':
            this.setState({
                verInfo: phoneOrMobileVeri(value)
            });
            return this.state.isPass = phoneOrMobileVeri(value) === null ? true : false;
        default:
            return true;
        }
    }

    render () {
        const common = this.props.modalCommon,
            inputProps = this.props.modalProps;

        return (
            <Modal animationType={'fade'} transparent={true} visible={common.visible}>
                <View style={styles.formModalViewInput}>
                    <View style={styles.formModalInputTitle}>
                        <Text style={[styles.formModalInputTitleText, this.state.verInfo !== null ?  {color: 'red'} : null]}>
                            {this.state.verInfo !== null ? this.state.verInfo : ('请输入' + inputProps.inputTItleValue)}
                        </Text>
                    </View>
                    <View style={styles.formModalInput}>
                        <TextInput style={styles.formModalInputItem} autoFocus={true} keyboardType={this.state.keyboardType}
                            autoCorrect={false} defaultValue={inputProps.modalInputValue}
                            maxLength={FIELD_MAX_LENGTH[common.fieldName]}
                            onChangeText={(value) => {
                                if (this.regexInputValue(value) && this.regexInputSQL(value)) {
                                    if (common.fieldName === 'Surname' || common.fieldName === 'Firstname' || 
                                    common.fieldName === 'SecSurname' || common.fieldName === 'SecFirstname' ||
                                    common.fieldName === 'CustNamePY') {
                                        this.setState({
                                            changeText: value.toUpperCase()
                                        });
                                    } else if (common.fieldName === 'CustNameCN') {
                                        this.setState({
                                            changeText: value
                                        });
                                    } else {
                                        this.setState({
                                            changeText: value.replace(/\s+/g,'')
                                        });
                                    }
                                }
                            }} />
                    </View>
                    <View style={styles.formModalInputButton}>
                        <TouchableHighlight onPress={() => {common.hideModal(!common.visible);}} underlayColor="transparent" style={styles.formModalInputButtonItem}>
                            <LinearGradient colors={['#727272', '#393939']} style={{width: '100%', paddingTop: 10, paddingBottom: 10, borderRadius: 5}}>
                                <Text style={styles.formModalInputButtonText}>取消</Text>
                            </LinearGradient>
                        </TouchableHighlight>
                        <TouchableHighlight onPress={() => {
                            if (this.state.isPass === true) {
                                common.confirmValue(common.fieldName, !common.visible, this.state.changeText.replace(/ /g,''));
                                this.setState({
                                    verInfo: null,
                                    changeText: null
                                });
                            }
                        }} underlayColor="transparent" style={styles.formModalInputButtonItem}>
                            <LinearGradient colors={['rgba(133, 195, 64, 1)', 'rgba(91, 150, 63, 1))']} style={{width: '100%', paddingTop: 10, paddingBottom: 10, borderRadius: 5}}>
                                <Text style={styles.formModalInputButtonText}>确定</Text>
                            </LinearGradient>
                        </TouchableHighlight>
                    </View>
                </View>
            </Modal>
        );
    }
}

export default FormModalInput;